   # Тестирование ПО УФ пеленгатора
   ## Запуск системы
```
    1. Установите зависимости:
      ```bash
      pip install requests selenium opencv-python
      ```

   2. Запустите симулятор:
      ```bash
      python simulator_py.py
      ```

   3. Запустите веб-интерфейс:
      ```bash
      python integration-test-script.py
      ```

   4. Для тестирования API используйте:
      ```bash
      python client_script.py
      ```

   5. Для запуска автотестов:
      ```bash
      python auto_test_script.py
      ```

   ## Описание компонентов
   - `simulator_py.py` — имитация устройства.
   - `complete-web-interface.html` — GUI для управления.
   - `integration-test-script.py` — основной скрипт интеграции.
   ```
